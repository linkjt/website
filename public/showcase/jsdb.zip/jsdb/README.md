# JSDB
## A New Markup Lang
JSDB is java script based and is the perfect edition to any of your projects
## Instalation
To install JSDB, just download the file, link jsdb.js to your main html file, make nessary configurations in the spec.json file, and use the rules.txt to help instruct you on where to use each on of the functions
## Contact
Questions, contact at falcigliajohn@gmail.com